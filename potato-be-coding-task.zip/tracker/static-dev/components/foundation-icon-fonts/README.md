# Quickstart

```
bower install foundation-icon-fonts
```
